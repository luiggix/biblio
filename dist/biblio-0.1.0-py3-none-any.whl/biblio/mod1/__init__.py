# Desde el .[nombre del archivo] importa [lista de funciones] 
from .suma import add

# que nombres se exportan si se usa from biblio.resta import * 
__all__ = ["add"]
